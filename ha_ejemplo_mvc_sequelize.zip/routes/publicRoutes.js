const express = require("express");
const publicRouter = express.Router();

// Rutas Públicas:
// ...

module.exports = publicRouter;
